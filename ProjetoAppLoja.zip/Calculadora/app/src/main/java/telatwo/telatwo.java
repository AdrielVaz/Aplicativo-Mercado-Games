package telatwo;

public interface telatwo {
}
