package com.example.calculadora;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {
    private ImageButton BackLogin;
    private ImageButton backButton;
    private EditText searchField;
    private ImageButton searchButton;
    private RecyclerView recyclerView;
    private ProductServiceAdapter adapter;
    private List<ProductService> productServiceList;
    private Button buttonBuy; // Adicionando o botão de compra

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Inicialização dos elementos da interface
        BackLogin = findViewById(R.id.BackLogin);
        backButton = findViewById(R.id.BackButton);
        searchField = findViewById(R.id.searchField2);
        searchButton = findViewById(R.id.SearchButton);
        recyclerView = findViewById(R.id.recyclerView2);
        buttonBuy = findViewById(R.id.ButtonBuy); // Encontrando o botão de compra

        // Configuração do RecyclerView
        productServiceList = new ArrayList<>();
        adapter = new ProductServiceAdapter(productServiceList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Carregar dados fictícios
        loadDummyData();

        // Configuração dos botões
        BackLogin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity3.this, MainActivity.class);
            startActivity(intent);
        });

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity3.this, MainActivity3.class);
            startActivity(intent);
        });

        searchButton.setOnClickListener(v -> {
            String query = searchField.getText().toString();
            if (query.isEmpty() || query.length() < 3) {
                // Faça alguma coisa se a consulta for muito curta
            } else {
                adapter.filter(query);
            }
        });

        // Configuração do botão de compra
        buttonBuy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity3.this, MainActivityPagamento.class);
                startActivity(intent);
            }
        });
    }

    private void loadDummyData() {
        productServiceList.add(new ProductService("USB", "Cabo USB Para controle", 100.0, R.drawable.product_image3));
        productServiceList.add(new ProductService("Destiny 2 ", "Jogo MMO RPG sand box Online", 150.0, R.drawable.product_image2));
        productServiceList.add(new ProductService("Controle PS4", "Controle PS4 Bluetooth", 200.0, R.drawable.product_image1));
        productServiceList.add(new ProductService("Manutenção de Aparelho eletrônico", "Serviço de Manutenção \n Endereço: Rua Costa Gomes, Abrantes\nNúmero: 7184249421", 0, R.drawable.img));
        productServiceList.add(new ProductService("PS4 FAT", "400gb Roda red dead 2 ", 2500.0, R.drawable.img_2));
        productServiceList.add(new ProductService("Xbox one s", "350gb Roda red dead 2 ", 2500.0, R.drawable.img_3));
        productServiceList.add(new ProductService("gta 5 ", "Jogo de tiro mundo aberto", 150.0, R.drawable.img_4));
        adapter.setProductServiceList(productServiceList);
    }
}
