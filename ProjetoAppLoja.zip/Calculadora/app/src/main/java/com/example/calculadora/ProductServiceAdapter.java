package com.example.calculadora;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProductServiceAdapter extends RecyclerView.Adapter<ProductServiceAdapter.ProductServiceViewHolder> {

    private List<ProductService> productServiceList;
    private List<ProductService> productServiceListFull;

    public ProductServiceAdapter(List<ProductService> productServiceList) {
        this.productServiceList = productServiceList;
        this.productServiceListFull = new ArrayList<>(productServiceList);
    }

    @NonNull
    @Override
    public ProductServiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main_item, parent, false);
        return new ProductServiceViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductServiceViewHolder holder, int position) {
        ProductService productService = productServiceList.get(position);
        holder.productName.setText(productService.getName());
        holder.productDescription.setText(productService.getDescription());
        holder.productPrice.setText(String.format("R$ %.2f", productService.getPrice()));
        holder.productImage.setImageResource(productService.getImageResourceId());
    }

    @Override
    public int getItemCount() {
        return productServiceList.size();
    }

    public void filter(String text) {
        productServiceList.clear();
        if (text.isEmpty()) {
            productServiceList.addAll(productServiceListFull);
        } else {
            text = text.toLowerCase();
            for (ProductService item : productServiceListFull) {
                if (item.getName().toLowerCase().contains(text) || item.getDescription().toLowerCase().contains(text)) {
                    productServiceList.add(item);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void setProductServiceList(List<ProductService> productServiceList) {
        this.productServiceList = productServiceList;
        this.productServiceListFull = new ArrayList<>(productServiceList);
        notifyDataSetChanged();
    }

    static class ProductServiceViewHolder extends RecyclerView.ViewHolder {
        TextView productName, productDescription, productPrice;
        ImageView productImage;

        ProductServiceViewHolder(@NonNull View itemView) {
            super(itemView);
            productName = itemView.findViewById(R.id.productName);
            productDescription = itemView.findViewById(R.id.productDescription);
            productPrice = itemView.findViewById(R.id.productPrice);
            productImage = itemView.findViewById(R.id.productImage);
        }
    }
}
