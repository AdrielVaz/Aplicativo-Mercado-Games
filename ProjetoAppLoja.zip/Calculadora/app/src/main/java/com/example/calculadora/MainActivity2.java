package com.example.calculadora;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity2 extends AppCompatActivity {
    Usuario usuario; // Objeto Usuario que armazena as informações do usuário
    FirebaseAuth autenticacao; // Objeto FirebaseAuth para autenticação com Firebase
    EditText campoNome, campoEmail, camposSenha; // Campos de entrada para nome, email e senha
    Button botaoCadastrar; // Botão para acionar o cadastro

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // Inicialização dos campos e botão
        campoNome = findViewById(R.id.EmailLogin);
        campoEmail = findViewById(R.id.Email);
        camposSenha = findViewById(R.id.SenhaLogin);
        botaoCadastrar = findViewById(R.id.CadastrarButton);

        // Configuração do listener para o botão de cadastrar
        botaoCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarCampos(v);
            }
        });
    }

    public void validarCampos(View view) {
        String nome = campoNome.getText().toString();
        String email = campoEmail.getText().toString();
        String pass = camposSenha.getText().toString();

        if (!nome.isEmpty()) { // Verifica se o campo nome não está vazio
            if (!email.isEmpty()) { // Verifica se o campo email não está vazio
                if (!pass.isEmpty()) { // Verifica se o campo senha não está vazio

                    usuario = new Usuario(); // Cria um novo objeto Usuario
                    usuario.setNome(nome); // Define o nome do usuário
                    usuario.setEmail(email); // Define o email do usuário
                    usuario.setPass(pass); // Define a senha do usuário

                    // Chama o método para cadastrar o usuário
                    cadastrarUsuario();

                } else {
                    Toast.makeText(this, "Preencha a senha", Toast.LENGTH_SHORT).show(); // Exibe mensagem se o campo senha estiver vazio
                }
            } else {
                Toast.makeText(this, "Preencha o email", Toast.LENGTH_SHORT).show(); // Exibe mensagem se o campo email estiver vazio
            }
        } else {
            Toast.makeText(this, "Preencha o nome", Toast.LENGTH_SHORT).show(); // Exibe mensagem se o campo nome estiver vazio
        }
    }

    private void cadastrarUsuario() {
        autenticacao = ConfigurarBd.Fireautenticacao(); // Obtém instância de autenticação do Firebase

        autenticacao.createUserWithEmailAndPassword(
                usuario.getEmail(), usuario.getPass()
        ).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(MainActivity2.this, "Sucesso ao Cadastrar o usuario", Toast.LENGTH_SHORT).show(); // Exibe mensagem de sucesso
                    Logar(); // Redireciona para a tela de login após sucesso
                } else {
                    Toast.makeText(MainActivity2.this, "Deu ruim!", Toast.LENGTH_SHORT).show(); // Exibe mensagem de erro
                }
            }
        });
    }

    public void Logar() {
        Intent in = new Intent(MainActivity2.this, MainActivity.class);
        startActivity(in);
    }

    public void Teladois(View view) {
        Intent in = new Intent(MainActivity2.this, MainActivity.class);
        startActivity(in);
    }
}
